package ventanas;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Tresportres extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_11;
	private JButton btnNewButton_6;
	private JButton btnSum;
	private JTextField textField22;
	private JTextField textField23;
	private JTextField textField24;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tresportres frame = new Tresportres();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Tresportres() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 560, 414);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 10, 524, 354);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ECUACIONES 3x3");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 15, 504, 27);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Ingrese los valores");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(126, 53, 260, 27);
		panel.add(lblNewLabel_1);
		
		
		
		JLabel lblNewLabel_2 = new JLabel("X");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_2.setBounds(83, 91, 46, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("+");
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(126, 91, 46, 15);
		panel.add(lblNewLabel_3);
		
		
		
		JLabel lblNewLabel_4 = new JLabel("Y");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_4.setBounds(207, 93, 46, 14);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("=");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(351, 92, 46, 14);
		panel.add(lblNewLabel_5);
		
		
		
		JLabel lblNewLabel_6 = new JLabel("X");
		lblNewLabel_6.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(83, 135, 46, 14);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("+");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_7.setBounds(126, 135, 46, 14);
		panel.add(lblNewLabel_7);
		
		
		
		JLabel lblNewLabel_8 = new JLabel("Y");
		lblNewLabel_8.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(207, 135, 46, 14);
		panel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("=");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_9.setBounds(351, 134, 46, 14);
		panel.add(lblNewLabel_9);
		
		
		
		JLabel lblNewLabel_10 = new JLabel("Z");
		lblNewLabel_10.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_10.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_10.setBounds(306, 91, 46, 14);
		panel.add(lblNewLabel_10);
		
		JLabel lblNewLabel_11 = new JLabel("Z");
		lblNewLabel_11.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_11.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_11.setBounds(306, 135, 46, 14);
		panel.add(lblNewLabel_11);
		
		JLabel lblNewLabel_12 = new JLabel("X");
		lblNewLabel_12.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_12.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_12.setBounds(83, 179, 46, 14);
		panel.add(lblNewLabel_12);
		
		JLabel lblNewLabel_13 = new JLabel("+");
		lblNewLabel_13.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_13.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_13.setBounds(124, 179, 46, 14);
		panel.add(lblNewLabel_13);
		
		JLabel lblNewLabel_14 = new JLabel("Y");
		lblNewLabel_14.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_14.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_14.setBounds(207, 179, 46, 14);
		panel.add(lblNewLabel_14);
		
		JLabel lblNewLabel_15 = new JLabel("Z");
		lblNewLabel_15.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_15.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_15.setBounds(306, 179, 46, 14);
		panel.add(lblNewLabel_15);
		
		JLabel lblNewLabel_16 = new JLabel("=");
		lblNewLabel_16.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_16.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_16.setBounds(351, 179, 46, 14);
		panel.add(lblNewLabel_16);
		
		textField = new JTextField();
		textField.setBounds(46, 83, 35, 35);
		textField.setFont(new Font("Arial", Font.PLAIN, 17));
		textField.setForeground(SystemColor.black);
		panel.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(180, 81, 35, 35);
		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_1.setForeground(SystemColor.black);
		panel.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(275, 81, 35, 35);
		textField_2.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_2.setForeground(SystemColor.black);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(390, 81, 35, 35);
		textField_3.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_3.setForeground(SystemColor.black);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();
		textField_4.setBounds(46, 125, 35, 35);
		textField_4.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_4.setForeground(SystemColor.black);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_5 = new JTextField();
		textField_5.setBounds(180, 125, 35, 35);
		textField_5.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_5.setForeground(SystemColor.black);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		textField_6 = new JTextField();
		textField_6.setBounds(275, 125, 35, 35);
		textField_6.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_6.setForeground(SystemColor.black);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		textField_7 = new JTextField();
		textField_7.setBounds(390, 125, 35, 35);
		textField_7.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_7.setForeground(SystemColor.black);
		panel.add(textField_7);
		textField_7.setColumns(10);
		
		textField_8 = new JTextField();
		textField_8.setBounds(46, 169, 35, 35);
		textField_8.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_8.setForeground(SystemColor.black);
		panel.add(textField_8);
		textField_8.setColumns(10);
		
		textField_9 = new JTextField();
		textField_9.setBounds(180, 169, 35, 35);
		textField_9.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_9.setForeground(SystemColor.black);
		panel.add(textField_9);
		textField_9.setColumns(10);
		
		textField_10 = new JTextField();
		textField_10.setBounds(275, 169, 35, 35);
		textField_10.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_10.setForeground(SystemColor.black);
		panel.add(textField_10);
		textField_10.setColumns(10);
		
		textField_11 = new JTextField();
		textField_11.setBounds(390, 169, 35, 35);
		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_11.setForeground(SystemColor.black);
		panel.add(textField_11);
		textField_11.setColumns(10);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ecuaciones frame = new Ecuaciones();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(46, 268, 98, 46);
		panel.add(btnNewButton_6);
		
		JLabel lblMostrar = new JLabel("X = ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(190, 213, 98, 46);
		panel.add(lblMostrar);
		
		btnSum = new JButton("ENTER");
		btnSum.setBackground(new Color(255, 255, 255));
		btnSum.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				float[][] matriz = new float[3][3];
                float[][] matrizInd = new float[3][3];
                float[][] matrizx = new float[3][3];
                float[][] matrizy = new float[3][3];
                float[][] matrizz = new float[3][3];
                float[][] delta = new float[5][3];
                float[][] deltax = new float[5][3];
                float[][] deltay = new float[5][3];
                float[][] deltaz = new float[5][3];
                
                
                matriz[0][0] = Integer.parseInt(textField.getText());
                matriz[0][1] = Integer.parseInt(textField_1.getText());
                matriz[0][2] = Integer.parseInt(textField_2.getText());
                matriz[1][0] = Integer.parseInt(textField_4.getText());
                matriz[1][1] = Integer.parseInt(textField_5.getText());
                matriz[1][2] = Integer.parseInt(textField_6.getText());
                matriz[2][0] = Integer.parseInt(textField_8.getText());
                matriz[2][1] = Integer.parseInt(textField_9.getText());
                matriz[2][2] = Integer.parseInt(textField_10.getText());
                matrizInd[0][0] = Integer.parseInt(textField_3.getText());
                matrizInd[1][0] = Integer.parseInt(textField_7.getText());
                matrizInd[2][0] = Integer.parseInt(textField_11.getText());
                
                for(int i = 0; i < 3 ; i++){
					for(int j = 0; j< 3; j++){
					
					 	matrizx[i][j] = matriz [i][j];
						matrizy[i][j] = matriz [i][j];
						matrizz[i][j] = matriz [i][j];
						
					}
				} 
				for(int i = 0; i < 3 ; i++){
					for(int j = 0; j< 1; j++){
					
					 	matrizx[i][j] = matrizInd [i][0];
						
					}
				}
				
				for(int i = 0; i < 3 ; i++){
					for(int j = 1; j< 2; j++){
					
						matrizy[i][j] = matrizInd [i][0];
						
					}
				}
				
				for(int i = 0; i < 3 ; i++){
					for(int j = 2; j< 3; j++){

						matrizz[i][j] = matrizInd [i][0];
						
					}
				}
				
				//det delta
				
				for(int i=0; i<3; i++){
					
					for(int j=0;j<3;j++){
						
						delta[i][j] = matriz[i][j]; 
						
					}
					
				}
				
				for(int i=3; i<5; i++){
					
					for(int j=0;j<3;j++){
						
						delta[i][j] = matriz[i-3][j]; 	
						
					}
					
				}
				
				//calculo delta g
				float a = delta[0][0] * delta[1][1] * delta[2][2];
				float b = delta[1][0] * delta[2][1] * delta[3][2];
				float c = delta[2][0] * delta[3][1] * delta[4][2];
				
				float	d = a + b + c;
				
				float e1 = delta[0][2] * delta[1][1] * delta[2][0];
				float f = delta[1][2] * delta[2][1] * delta[3][0];
				float g = delta[2][2] * delta[3][1] * delta[4][0];
				
				float	h = e1 + f + g;				
				
				float detdelta = d - h;
				
				
				//det delta
				
				for(int i=0; i<3; i++){
					
					for(int j=0;j<3;j++){
						
						deltax[i][j] = matrizx[i][j]; 
						
					}
					
				}
				
				for(int i=3; i<5; i++){
					
					for(int j=0;j<3;j++){
						
						deltax[i][j] = matrizx[i-3][j]; 	
						
					}
					
				}
				
				//calculo delta x
				a = deltax[0][0] * deltax[1][1] * deltax[2][2];
				b = deltax[1][0] * deltax[2][1] * deltax[3][2];
				c = deltax[2][0] * deltax[3][1] * deltax[4][2];
				
				d = a + b + c;
				
				e1 = deltax[0][2] * deltax[1][1] * deltax[2][0];
				f = deltax[1][2] * deltax[2][1] * deltax[3][0];
				g = deltax[2][2] * deltax[3][1] * deltax[4][0];
				
				h = e1 + f + g;				
				
				float detx = d - h;
				
				
				//det delta y 
				
				for(int i=0; i<3; i++){
					
					for(int j=0;j<3;j++){
						
						deltay[i][j] = matrizy[i][j]; 
						
					}
					
				}
				
				for(int i=3; i<5; i++){
					
					for(int j=0;j<3;j++){
						
						deltay[i][j] = matrizy[i-3][j]; 	
						
					}
					
				}
				
				//calculo delta y
				a = deltay[0][0] * deltay[1][1] * deltay[2][2];
				b = deltay[1][0] * deltay[2][1] * deltay[3][2];
				c = deltay[2][0] * deltay[3][1] * deltay[4][2];
				
				d = a + b + c;
				
				e1 = deltay[0][2] * deltay[1][1] * deltay[2][0];
				f = deltay[1][2] * deltay[2][1] * deltay[3][0];
				g = deltay[2][2] * deltay[3][1] * deltay[4][0];
				
				h = e1 + f + g;				
				
				float dety = d - h;
				
				
				//det delta z
				
				for(int i=0; i<3; i++){
					
					for(int j=0;j<3;j++){
						
						deltaz[i][j] = matrizz[i][j]; 
						
					}
					
				}
				
				for(int i=3; i<5; i++){
					
					for(int j=0;j<3;j++){
						
						deltaz[i][j] = matrizz[i-3][j]; 	
						
					}
					
				}
				
				//calculo delta z
				a = deltaz[0][0] * deltaz[1][1] * deltaz[2][2];
				b = deltaz[1][0] * deltaz[2][1] * deltaz[3][2];
				c = deltaz[2][0] * deltaz[3][1] * deltaz[4][2];
				
				d = a + b + c;
				
				e1 = deltaz[0][2] * deltaz[1][1] * deltaz[2][0];
				f = deltaz[1][2] * deltaz[2][1] * deltaz[3][0];
				g = deltaz[2][2] * deltaz[3][1] * deltaz[4][0];
				
				h = e1 + f + g;				
                
				float detz = d - h;
				
				float x = detx / detdelta;   
				
				float y = dety / detdelta;
				
				float z = detz / detdelta;
				
	    		textField22 = new JTextField();
	    		textField22.setEnabled(true);
	    		textField22.setEditable(false);
	    		textField22.setColumns(10);
	    		textField22.setBounds(264, 207, 35, 35);
	    		textField22.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField22.setForeground(SystemColor.black);
	    		panel.add(textField22);
	            textField22.setText(String.valueOf(x));
	            
	    		textField23 = new JTextField();
	    		textField23.setEnabled(true);
	    		textField23.setEditable(false);
	    		textField23.setColumns(10);
	    		textField23.setBounds(264, 250, 35, 35);
	    		textField23.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField23.setForeground(SystemColor.black);
	    		panel.add(textField23);
	            textField23.setText(String.valueOf(y));
	            
	            textField24 = new JTextField();
	    		textField24.setEnabled(true);
	    		textField24.setEditable(false);
	    		textField24.setColumns(10);
	    		textField24.setBounds(264, 293, 35, 35);
	    		textField24.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField24.setForeground(SystemColor.black);
	    		panel.add(textField24);
	            textField24.setText(String.valueOf(z));
			}
		});
		btnSum.setBounds(46, 218, 98, 39);
		btnSum.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum.setBorder(null);
		btnSum.setBackground(Color.WHITE);
		panel.add(btnSum);
		
		JLabel lblY = new JLabel("Y = ");
		lblY.setHorizontalAlignment(SwingConstants.CENTER);
		lblY.setFont(new Font("Arial", Font.PLAIN, 17));
		lblY.setBounds(190, 254, 98, 46);
		panel.add(lblY);
		
		JLabel lblZ = new JLabel("Z = ");
		lblZ.setHorizontalAlignment(SwingConstants.CENTER);
		lblZ.setFont(new Font("Arial", Font.PLAIN, 17));
		lblZ.setBounds(190, 297, 98, 46);
		panel.add(lblZ);
		
		JLabel lblNewLabel_3_1 = new JLabel("+");
		lblNewLabel_3_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_3_1.setBounds(239, 91, 46, 15);
		panel.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_1_1 = new JLabel("+");
		lblNewLabel_3_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_1.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_3_1_1.setBounds(239, 135, 46, 15);
		panel.add(lblNewLabel_3_1_1);
		
		JLabel lblNewLabel_3_1_2 = new JLabel("+");
		lblNewLabel_3_1_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3_1_2.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_3_1_2.setBounds(239, 179, 46, 15);
		panel.add(lblNewLabel_3_1_2);
		
	}
}