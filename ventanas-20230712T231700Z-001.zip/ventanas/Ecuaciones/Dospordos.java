package ventanas;

import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.SwingConstants;
import javax.swing.JTextField;

public class Dospordos extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JButton btnNewButton_6;
	private JButton btnSum;
	private JTextField textField22;
	private JTextField textField23;
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Dospordos frame = new Dospordos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Dospordos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 497, 375);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 461, 318);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ECUACIONES 2x2");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel.setBounds(-11, 11, 485, 31);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Ingresar valores");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(74, 53, 315, 35);
		panel.add(lblNewLabel_1);
		
		textField = new JTextField();//valor A primera ecuacion
		textField.setBounds(54, 90, 35, 35);
		textField.setFont(new Font("Arial", Font.PLAIN, 17));
		textField.setForeground(SystemColor.black);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("X");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_2.setBounds(84, 98, 46, 14);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("+");
		lblNewLabel_3.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBounds(120, 98, 46, 15);
		panel.add(lblNewLabel_3);
		
		textField_2 = new JTextField();//valor B primera ecuacion
		textField_2.setBounds(162, 90, 35, 35);
		textField_2.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_2.setForeground(SystemColor.black);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Y");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_4.setBounds(205, 100, 46, 14);
		panel.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("=");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(239, 101, 46, 14);
		panel.add(lblNewLabel_5);
		
		textField_3 = new JTextField();// valor C o resultado primr ecuacion
		textField_3.setBounds(302, 90, 35, 35);
		textField_3.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_3.setForeground(SystemColor.black);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		textField_4 = new JTextField();//valor D segunda ecuacion
		textField_4.setBounds(54, 142, 35, 35);
		textField_4.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_4.setForeground(SystemColor.black);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("X");
		lblNewLabel_6.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setBounds(86, 150, 46, 14);
		panel.add(lblNewLabel_6);
		
		JLabel lblNewLabel_7 = new JLabel("+");
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_7.setBounds(120, 150, 46, 14);
		panel.add(lblNewLabel_7);
		
		textField_5 = new JTextField();//valor E segunda ecuacion
		textField_5.setBounds(162, 142, 35, 35);
		textField_5.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_5.setForeground(SystemColor.black);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Y");
		lblNewLabel_8.setFont(new Font("Arial", Font.BOLD, 17));
		lblNewLabel_8.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_8.setBounds(205, 152, 46, 14);
		panel.add(lblNewLabel_8);
		
		JLabel lblNewLabel_9 = new JLabel("=");
		lblNewLabel_9.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_9.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_9.setBounds(239, 151, 46, 14);
		panel.add(lblNewLabel_9);
		
		textField_6 = new JTextField();//valor F o resultado segunda ecuacion
		textField_6.setBounds(302, 142, 35, 35);
		textField_6.setFont(new Font("Arial", Font.PLAIN, 17));
		textField_6.setForeground(SystemColor.black);
		panel.add(textField_6);
		textField_6.setColumns(10);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ecuaciones frame = new Ecuaciones();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(54, 253, 98, 39);
		panel.add(btnNewButton_6);
		
		JLabel lblMostrar = new JLabel("Y = ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(173, 189, 133, 46);
		panel.add(lblMostrar);
		
		btnSum = new JButton("ENTER");
		btnSum.setBackground(new Color(255, 255, 255));
		btnSum.setBounds(54, 203, 98, 39);
		btnSum.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				float a, b, c, d, e1, f, D, Dx, Dy, X, Y;
				a = Integer.parseInt(textField.getText());
				b = Integer.parseInt(textField_2.getText());
				c = Integer.parseInt(textField_3.getText());
				d = Integer.parseInt(textField_4.getText());
				e1 = Integer.parseInt(textField_5.getText());
				f = Integer.parseInt(textField_6.getText());
				
				D = (a * e1) - (d * b);
                Dx = (b * f) - (e1 * c);
                Dy = (a * f) - (d * c);
                
                X = Dx / D;
                Y = Dy / D;

                X = X * (-1);
                
	    		textField22 = new JTextField();
	    		textField22.setEnabled(true);
	    		textField22.setEditable(false);
	    		textField22.setColumns(10);
	    		textField22.setBounds(264, 187, 35, 35);
	    		textField22.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField22.setForeground(SystemColor.black);
	    		panel.add(textField22);
	            textField22.setText(String.valueOf(Y));
	            
	    		textField23 = new JTextField();
	    		textField23.setEnabled(true);
	    		textField23.setEditable(false);
	    		textField23.setColumns(10);
	    		textField23.setBounds(264, 246, 35, 35);
	    		textField23.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField23.setForeground(SystemColor.black);
	    		panel.add(textField23);
	            textField23.setText(String.valueOf(X));
			}
		});
		btnSum.setBorder(null);
		btnSum.setBackground(Color.WHITE);
		// esta pendiente de las acciones del button
		panel.add(btnSum);
		
		JLabel lblX = new JLabel("X = ");
		lblX.setHorizontalAlignment(SwingConstants.CENTER);
		lblX.setFont(new Font("Arial", Font.PLAIN, 17));
		lblX.setBounds(173, 246, 133, 46);
		panel.add(lblX);
		
	}
}