package ventanas;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;

public class Ventana extends JFrame implements ActionListener{
	private JPanel panelprincipal;
	private JPanel panel;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JButton btnNewButton_2;

	/**
	 * Launch the application.
	 */
/*	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana frame = new Ventana();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
*/
	public Ventana() {
		setTitle("CALCULADORA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //cierra ventana con el exit 
		setBounds(100, 100, 632, 760);                
		panelprincipal = new JPanel();
		panelprincipal.setBackground(new Color(0, 0, 0));
		panelprincipal.setBorder(new EmptyBorder(5,5, 3, 5));
		setContentPane(panelprincipal);
		panelprincipal.setLayout(null);
		
		panel = new JPanel();
		panel.setBounds(10, 11, 596, 699);
		panel.setBackground(new Color(104, 141, 204));
		panel.setForeground(new Color(64, 0, 64));
		panelprincipal.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("¿QUE OPERACION DESEA REALIZAR?");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 85, 572, 39);
		panel.add(lblNewLabel_1);
		
		lblNewLabel_1 = new JLabel("NUMEROS NATURALES");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel_1.setBounds(10, 11, 572, 45);
		panel.add(lblNewLabel_1);
		
		btnNewButton = new JButton("OPERACIONES BASICAS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Sumar frame = new Sumar();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(10, 159, 274, 399);
		panel.add(btnNewButton);
		
		btnNewButton_1 = new JButton("POTENCIA O RAIZ");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Potencia frame = new Potencia();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setBackground(Color.WHITE);
		btnNewButton_1.setBounds(294, 159, 281, 399);
		panel.add(btnNewButton_1);
		
		btnNewButton_2 = new JButton("VOLVER");
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Inicio frame = new Inicio();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_2.setBorder(null);
		btnNewButton_2.setBackground(Color.WHITE);
		btnNewButton_2.setBounds(10, 569, 572, 119);
		panel.add(btnNewButton_2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

	//@Override
	/*public void actionPerformed(ActionEvent e) {
		if (btnSum==e.getSource()) {
			
			int num1=Integer.parseInt(TXTNum1.getText());
			int num2=Integer.parseInt(TXTNum2.getText());
			int Suma= num1+num2;
			JOptionPane.showMessageDialog(null, "         la suma es " + Suma);  //Salida del mensaje 
			
		}
	}*/
}