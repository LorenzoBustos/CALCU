package ventanas;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.SystemColor;


public class Sumar extends JFrame implements ActionListener{
	private JButton btnSum_1;
	private JButton btnSum_2;
	private JButton btnSum_3;
	private JButton btnSum_4;
	private JButton btnSum;
	private JPanel contentPane;
	private JPanel panel;
	private JTextField TXTNum1;
	private JTextField TXTNum2;
	private JTextField TXTNum3;
	private JTextField TXTNum4;
	private JTextField TXTNum5;
	private JTextField textField;
	private JLabel lblMostrar;
	private JButton btnNewButton_6;
	private JPanel resultadoPane;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sumar frame = new Sumar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sumar() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 760);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 596, 699);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("NUMEROS NATURALES");
		lblNewLabel_1.setBounds(90, 11, 378, 39);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 33));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("OPERACIONES BASICAS");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(0, 61, 572, 39);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNum2 = new JLabel("Ingresar con cuantos numeros desea trabajar");
		lblNum2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum2.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum2.setBounds(10, 112, 403, 46);
		panel.add(lblNum2);
		
		JLabel lblMostrar = new JLabel("El resultado es: ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(113, 480, 190, 46);
		panel.add(lblMostrar);
		
		TXTNum1 = new JTextField();
		TXTNum1.setBounds(406, 120, 35, 35);
		TXTNum1.setForeground(SystemColor.black);
		TXTNum1.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum1.setColumns(10);
		panel.add(TXTNum1);
		
		btnSum = new JButton("ENTER");
		btnSum.setBackground(new Color(255, 255, 255));
		btnSum.setBounds(230, 169, 98, 39);
		btnSum.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum.setBorder(null);
		btnSum.setBackground(Color.WHITE);
		btnSum.addActionListener(this);  // esta pendiente de las acciones del button
		panel.add(btnSum);
		
		TXTNum2 = new JTextField();
		TXTNum2.setEnabled(false);
		TXTNum2.setEditable(false);
		TXTNum2.setBounds(175, 282, 35, 35);
		TXTNum2.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum2.setForeground(SystemColor.black);
		TXTNum2.setColumns(10);
		panel.add(TXTNum2);
		
		TXTNum3 = new JTextField();
		TXTNum3.setEnabled(false);
		TXTNum3.setEditable(false);
		TXTNum3.setBounds(230, 282, 35, 35);
		TXTNum3.setForeground(SystemColor.black);
		TXTNum3.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum3.setColumns(10);
		panel.add(TXTNum3);
		
		TXTNum4 = new JTextField();
		TXTNum4.setEnabled(false);
		TXTNum4.setEditable(false);
		TXTNum4.setBounds(285, 282, 35, 35);
		TXTNum4.setForeground(SystemColor.black);
		TXTNum4.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum4.setColumns(10);
		panel.add(TXTNum4);
		
		TXTNum5 = new JTextField();
		TXTNum5.setEnabled(false);
		TXTNum5.setEditable(false);
		TXTNum5.setBounds(340, 282, 35, 35);
		TXTNum5.setForeground(SystemColor.black);
		TXTNum5.setFont(new Font("Arial", Font.PLAIN, 17));
		panel.add(TXTNum5);
		TXTNum5.setColumns(10);
		panel.add(TXTNum5);
		
		JLabel lblNum3 = new JLabel("Ingresar numeros");
		lblNum3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum3.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum3.setBounds(75, 225, 403, 46);
		panel.add(lblNum3);
		
		JButton btnSum_1 = new JButton("SUMAR");
		btnSum_1.setBackground(new Color(255, 255, 255));
		btnSum_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_1.setBorder(null);
		btnSum_1.setBackground(Color.WHITE);
		btnSum_1.setBounds(46, 398, 98, 55);
		btnSum_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				float resultado = 0;
				int[] vector = {0, 0, 0, 0};
				int n=Integer.parseInt(TXTNum1.getText());
				
				switch(n){
	              case 1:	            
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = 0;
	                  vector[2] = 0;
	                  vector[3] = 0;
	                  
	                  break;
	              case 2:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = 0;
	                  vector[3] = 0;
	                 
	                  break;
	              case 3:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = Integer.parseInt(TXTNum4.getText());
	                  vector[3] = 0;
	                  break;
	              case 4:
	                    vector[0] = Integer.parseInt(TXTNum2.getText());
	                    vector[1] = Integer.parseInt(TXTNum3.getText());
	                    vector[2] = Integer.parseInt(TXTNum4.getText());
	                    vector[3] = Integer.parseInt(TXTNum5.getText());
	                  break;
				}
	            for (int i = 0; i < n; i++) {
	                resultado += vector[i];
	             
	            }
	            
	    		textField = new JTextField();
	    		textField.setEnabled(true);
	    		textField.setEditable(false);
	    		textField.setColumns(10);
	    		textField.setBounds(293, 487, 70, 35);
	    		textField.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField.setForeground(SystemColor.black);
	    		panel.add(textField);
	            textField.setText(String.valueOf(resultado));
			}
		});
		panel.add(btnSum_1);
		
		JButton btnSum_2 = new JButton("RESTAR");
		btnSum_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnSum_2.setBackground(new Color(255, 255, 255));
		btnSum_2.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_2.setBorder(null);
		btnSum_2.setBackground(Color.WHITE);
		btnSum_2.setBounds(154, 398, 98, 55);
		btnSum_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int[] vector = {0, 0, 0, 0};
				int n=Integer.parseInt(TXTNum1.getText());
				
				switch(n){
		          case 1:	            
		              vector[0] = Integer.parseInt(TXTNum2.getText());
		              vector[1] = 0;
		              vector[2] = 0;
		              vector[3] = 0;
		              
		              break;
		          case 2:
		              vector[0] = Integer.parseInt(TXTNum2.getText());
		              vector[1] = Integer.parseInt(TXTNum3.getText());
		              vector[2] = 0;
		              vector[3] = 0;
		   
		              break;
		          case 3:
		              vector[0] = Integer.parseInt(TXTNum2.getText());
		              vector[1] = Integer.parseInt(TXTNum3.getText());
		              vector[2] = Integer.parseInt(TXTNum4.getText());
		              vector[3] = 0;
		              break;
		          case 4:
		                vector[0] = Integer.parseInt(TXTNum2.getText());
		                vector[1] = Integer.parseInt(TXTNum3.getText());
		                vector[2] = Integer.parseInt(TXTNum4.getText());
		                vector[3] = Integer.parseInt(TXTNum5.getText());
		              break;
				}
				
				float resultado = vector[0];
				
		        for (int i = 1; i < n; i++) {
		            resultado -= vector[i];
		        }

				textField = new JTextField();
				textField.setEnabled(true);
				textField.setEditable(false);
				textField.setColumns(10);
				textField.setBounds(293, 487, 70, 35);
				textField.setFont(new Font("Arial", Font.PLAIN, 17));
				textField.setForeground(SystemColor.black);
				panel.add(textField);
		        textField.setText(String.valueOf(resultado));
				
			}
		});
		panel.add(btnSum_2);
		
		
		JButton btnSum_3 = new JButton("MULTIPLICAR");
		btnSum_3.setBackground(new Color(255, 255, 255));
		btnSum_3.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3.setBorder(null);
		btnSum_3.setBackground(Color.WHITE);
		btnSum_3.setBounds(263, 398, 133, 55);
		btnSum_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				float resultado = 1;
				int[] vector = {0, 0, 0, 0};
				int n=Integer.parseInt(TXTNum1.getText());
				
				switch(n){
	              case 1:	            
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = 0;
	                  vector[2] = 0;
	                  vector[3] = 0;
	                  
	                  break;
	              case 2:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = 0;
	                  vector[3] = 0;
	       
	                  break;
	              case 3:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = Integer.parseInt(TXTNum4.getText());
	                  vector[3] = 0;
	                  break;
	              case 4:
	                    vector[0] = Integer.parseInt(TXTNum2.getText());
	                    vector[1] = Integer.parseInt(TXTNum3.getText());
	                    vector[2] = Integer.parseInt(TXTNum4.getText());
	                    vector[3] = Integer.parseInt(TXTNum5.getText());
	                  break;
				}
				
              for (int i = 0; i < n; i++) {
                  resultado *= vector[i];
              }
				
	      		textField = new JTextField();
	      		textField.setEnabled(true);
	      		textField.setEditable(false);
	      		textField.setColumns(10);
	      		textField.setBounds(293, 487, 70, 35);
	      		textField.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField.setForeground(SystemColor.black);
	      		panel.add(textField);
	      		textField.setText(String.valueOf(resultado));
				
			}
		});
		panel.add(btnSum_3);
		
		JButton btnSum_4 = new JButton("DIVIDIR");
		btnSum_4.setBackground(new Color(255, 255, 255));
		btnSum_4.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_4.setBorder(null);
		btnSum_4.setBackground(Color.WHITE);
		btnSum_4.setBounds(406, 398, 98, 55);
		btnSum_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int[] vector = {0, 0, 0, 0};
				int n=Integer.parseInt(TXTNum1.getText());
				switch(n){
	              case 1:	            
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = 0;
	                  vector[2] = 0;
	                  vector[3] = 0;
	                  
	                  break;
	              case 2:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = 0;
	                  vector[3] = 0;
	       
	                  break;
	              case 3:
	                  vector[0] = Integer.parseInt(TXTNum2.getText());
	                  vector[1] = Integer.parseInt(TXTNum3.getText());
	                  vector[2] = Integer.parseInt(TXTNum4.getText());
	                  vector[3] = 0;
	                  break;
	              case 4:
	                    vector[0] = Integer.parseInt(TXTNum2.getText());
	                    vector[1] = Integer.parseInt(TXTNum3.getText());
	                    vector[2] = Integer.parseInt(TXTNum4.getText());
	                    vector[3] = Integer.parseInt(TXTNum5.getText());
	                  break;
				}
				
				float resultado = vector[0];
				
              for (int i = 1; i < n; i++) {
                  resultado /= vector[i];
              }
				
      			textField = new JTextField();
      			textField.setEnabled(true);
      			textField.setEditable(false);
      			textField.setColumns(10);
      			textField.setBounds(293, 487, 70, 35);
      			textField.setFont(new Font("Arial", Font.PLAIN, 17));
      			textField.setForeground(SystemColor.black);
      			panel.add(textField);
      			textField.setText(String.valueOf(resultado));
      						
			}
		});
		panel.add(btnSum_4);
		
		JLabel lblNum4 = new JLabel("¿Que operacion desea realizar?");
		lblNum4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum4.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum4.setBounds(75, 341, 403, 46);
		panel.add(lblNum4);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ventana frame = new Ventana();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(10, 589, 576, 99);
		panel.add(btnNewButton_6);
		
		
		
		
	}
	
	public void actionPerformed(ActionEvent e) {
		
		int n=Integer.parseInt(TXTNum1.getText());
		
		if (btnSum==e.getSource()) {
			
			
			int[] vector = {0, 0, 0, 0};
				    
				switch(n){
	              case 1:
	            	  TXTNum2.setEnabled(true);
	                  TXTNum2.setEditable(true);
	                  break;
	              case 2:

	                  TXTNum2.setEnabled(true);
	                  TXTNum2.setEditable(true);
	                  TXTNum3.setEnabled(true);
	                  TXTNum3.setEditable(true);
	                  
	       
	                  break;
	              case 3:
	                  TXTNum2.setEnabled(true);
	                  TXTNum2.setEditable(true);
	                  TXTNum3.setEnabled(true);
	                  TXTNum3.setEditable(true);
	                  TXTNum4.setEnabled(true);
	                  TXTNum4.setEditable(true);
	                 
	                  break;
	              case 4:
	                  TXTNum2.setEnabled(true);
	                  TXTNum2.setEditable(true);
	                  TXTNum3.setEnabled(true);
	                  TXTNum3.setEditable(true);
	                  TXTNum4.setEnabled(true);
	                  TXTNum4.setEditable(true);
	                  TXTNum5.setEnabled(true);
	                  TXTNum5.setEditable(true);
	                  break;
	                  
	              default:
	            	  JOptionPane.showMessageDialog(null, "ERROR. INGRESE UN DATO VALIDO");
	            	 
	            	  break;
				}		
			
		}
		
	}
}