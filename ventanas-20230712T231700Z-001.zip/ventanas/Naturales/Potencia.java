package ventanas;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.TextField;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Potencia extends JFrame {

	private JPanel contentPane;
	private JButton btnSum_1;
	private JPanel panelprincipal;
	private JPanel panel;
	private JTextField TXTNum2;
	private JTextField TXTNum3;
	private JTextField textField;
	private JButton btnNewButton_6;
	private JButton btnSum_1_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Potencia frame = new Potencia();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Potencia() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 760);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 596, 699);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblMostrar = new JLabel("El resultado es: ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(101, 494, 190, 46);
		panel.add(lblMostrar);
		
		JLabel lblNewLabel_1 = new JLabel("NUMEROS NATURALES");
		lblNewLabel_1.setBounds(107, 23, 378, 39);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 33));
		panel.add(lblNewLabel_1);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ventana frame = new Ventana();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(10, 589, 576, 99);
		panel.add(btnNewButton_6);
		
		JLabel lblNewLabel_1_1 = new JLabel("Ingrese los numeros a operar");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(0, 88, 572, 39);
		panel.add(lblNewLabel_1_1);
		
		TXTNum2 = new JTextField();
		TXTNum2.setBounds(229, 158, 35, 35);
		TXTNum2.setForeground(SystemColor.black);
		TXTNum2.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum2.setColumns(10);
		panel.add(TXTNum2);
		
		TXTNum3 = new JTextField();
		TXTNum3.setBounds(484, 158, 35, 35);
		TXTNum3.setForeground(SystemColor.black);
		TXTNum3.setFont(new Font("Arial", Font.PLAIN, 17));
		TXTNum3.setColumns(10);
		panel.add(TXTNum3);
		
		JLabel lblNum3 = new JLabel("Ingresar numero");
		lblNum3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum3.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum3.setBounds(66, 165, 129, 21);
		panel.add(lblNum3);
		
		JButton btnSum_1 = new JButton("RAIZ");
		btnSum_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int numA=Integer.parseInt(TXTNum2.getText());
				int m = Integer.parseInt(TXTNum3.getText());
				
				int raiz = 1 / m;
				
				float resultado = (float) Math.pow(numA, raiz);
				
	     		textField = new JTextField();
	    		textField.setEnabled(true);
	    		textField.setEditable(false);
	    		textField.setColumns(10);
	    		textField.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField.setForeground(SystemColor.black);
	    		textField.setBounds(267, 504, 70, 35);
	    		panel.add(textField);
	            textField.setText(String.valueOf(resultado));
			}
		});
		btnSum_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_1.setBorder(null);
		btnSum_1.setBackground(Color.WHITE);
		btnSum_1.setBounds(311, 260, 275, 223);
		panel.add(btnSum_1);
		
		JLabel lblIngresarExponente = new JLabel("Ingresar exponente");
		lblIngresarExponente.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngresarExponente.setFont(new Font("Arial", Font.PLAIN, 17));
		lblIngresarExponente.setBounds(319, 165, 155, 21);
		panel.add(lblIngresarExponente);
		
		JButton btnSum_1_2 = new JButton("POTENCIA");
		btnSum_1_2.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_1_2.setBorder(null);
		btnSum_1_2.setBackground(Color.WHITE);
		btnSum_1_2.setBounds(10, 260, 281, 223);
		btnSum_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int numA=Integer.parseInt(TXTNum2.getText());
				int pot = Integer.parseInt(TXTNum3.getText());
				
				
				float resultado = (float) Math.pow(numA, pot);
				
	     		textField = new JTextField();
	    		textField.setEnabled(true);
	    		textField.setEditable(false);
	    		textField.setColumns(10);
	    		textField.setBounds(267, 504, 70, 35);
	    		textField.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField.setForeground(SystemColor.black);
	    		panel.add(textField);
	            textField.setText(String.valueOf(resultado));
			}
		});
		panel.add(btnSum_1_2);
		
		
	}
	}