package ventanas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.SwingConstants;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;

public class Calculosvectores2 extends JFrame {

	private JPanel contentPane;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField5;
	private JButton btnNewButton_6;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculosvectores frame = new Calculosvectores();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculosvectores2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 791, 486);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 755, 425);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("VECTORES");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel.setBounds(227, 11, 287, 54);
		panel.add(lblNewLabel);
		
		JLabel lblMostrar = new JLabel("El resultado es: ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(98, 289, 190, 46);
		panel.add(lblMostrar);
		
		
		JButton btnSum_3_1 = new JButton("VECTOR POR ESCALAR");
		btnSum_3_1.setBackground(new Color(255, 255, 255));
		btnSum_3_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String vectorl = textField_2.getText();
				int num=Integer.parseInt(textField_3.getText());
				String[] elementos = vectorl.split(" ");
				int acu = 0;
				
				int[] vector = new int[elementos.length];
				int[] vectorC = new int[elementos.length];
				for (int i = 0; i < elementos.length; i++) {
				    vector[i] = Integer.parseInt(elementos[i]);
				}				

				
				for (int i = 0; i < elementos.length; i++) {
                    vectorC[i] = vector[i] * num;
                }
				
					
				String texto = "";
				
				for (int i = 0; i < vector.length; i++) {
				    texto += vectorC[i];
				    
				    if (i < vector.length - 1) {
				        texto += ", ";
				    }
				}
				textField5 = new JTextField();
				textField5.setEnabled(true);
	    		textField5.setEditable(false);
	    		textField5.setColumns(10);
	    		textField5.setBounds(298, 289, 242, 35);
	    		textField5.setFont(new Font("Arial", Font.PLAIN, 17));
	    		textField5.setForeground(SystemColor.black);
	    		panel.add(textField5);
	            textField5.setText(texto);
			}
		});
		btnSum_3_1.setFont(new Font("Arial", Font.PLAIN, 14));
		btnSum_3_1.setBounds(263, 225, 202, 39);
		panel.add(btnSum_3_1);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Ingrese los valores del primer vector separados por espacios");
		lblNewLabel_1_1_2.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1_2.setBounds(17, 92, 448, 39);
		panel.add(lblNewLabel_1_1_2);
		
		JLabel lblNewLabel_1_1_3 = new JLabel("Ingrese escalar");
		lblNewLabel_1_1_3.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1_3.setBounds(312, 153, 170, 39);
		panel.add(lblNewLabel_1_1_3);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(475, 96, 242, 35);
		textField_2.setForeground(SystemColor.black);
		textField_2.setFont(new Font("Arial", Font.PLAIN, 17));
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(443, 157, 274, 35);
		textField_3.setForeground(SystemColor.black);
		textField_3.setFont(new Font("Arial", Font.PLAIN, 17));
		panel.add(textField_3);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Vectores frame = new Vectores();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(263, 346, 202, 50);
		panel.add(btnNewButton_6);
	}
}