package ventanas;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.SystemColor;


public class Calculosmatrices extends JFrame implements ActionListener{
	private JButton btnSum_1;
	private JButton btnSum_2;
	private JButton btnSum_3;
	private JButton btnSum_4;
	private JPanel contentPane;
	private JPanel panel;
	private JTextField textField;
	private JLabel lblMostrar;
	private JButton btnNewButton_6;
	private JPanel resultadoPane;
	private JTextField txtGf;
	private JTextField textField_5;
	private JTextField textField_4;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_1;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField22;
	private JTextField textField_19;
	private JTextField textField_20;
	private JTextField textField_21;
	private JTextField textField_22;
	private JTextField textField_23;
	private JTextField textField_24;
	private JTextField textField_25;
	private JTextField textField_26;
	private JTextField textField_27;
	private JTextField textField_2;
	private JTextField textField_3;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculosmatrices frame = new Calculosmatrices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculosmatrices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 696);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 596, 635);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("MATRICES");
		lblNewLabel_1.setBounds(101, 11, 378, 39);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 33));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("OPERACIONES CON 2 MATRICES");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(130, 55, 308, 39);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblMostrar = new JLabel("El resultado es: ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(95, 448, 171, 46);
		panel.add(lblMostrar);
		
		JLabel lblNum4 = new JLabel("¿Que operacion desea realizar?");
		lblNum4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum4.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum4.setBounds(101, 327, 403, 46);
		panel.add(lblNum4);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Matrices frame = new Matrices();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(458, 384, 108, 39);
		panel.add(btnNewButton_6);
		
		JButton btnSum_3_1 = new JButton("SUMA");
		btnSum_3_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
                int i, j;
                
                int[][] matriz_a = new int[3][3];
                int[][] matriz_b = new int[3][3];
                int[][] matriz_c = new int[3][3];
                
                
                matriz_a[0][0] = Integer.parseInt(txtGf.getText());
                matriz_a[0][1] = Integer.parseInt(textField_3.getText());
                matriz_a[0][2] = Integer.parseInt(textField_4.getText());
                matriz_a[1][0] = Integer.parseInt(textField_5.getText());
                matriz_a[1][1] = Integer.parseInt(textField_6.getText());
                matriz_a[1][2] = Integer.parseInt(textField_7.getText());
                matriz_a[2][0] = Integer.parseInt(textField_8.getText());
                matriz_a[2][1] = Integer.parseInt(textField_9.getText());
                matriz_a[2][2] = Integer.parseInt(textField_10.getText());
                
                matriz_b[0][0] = Integer.parseInt(textField_19.getText());
                matriz_b[0][1] = Integer.parseInt(textField_20.getText());
                matriz_b[0][2] = Integer.parseInt(textField_21.getText());
                matriz_b[1][0] = Integer.parseInt(textField_22.getText());
                matriz_b[1][1] = Integer.parseInt(textField_23.getText());
                matriz_b[1][2] = Integer.parseInt(textField_24.getText());
                matriz_b[2][0] = Integer.parseInt(textField_25.getText());
                matriz_b[2][1] = Integer.parseInt(textField_26.getText());
                matriz_b[2][2] = Integer.parseInt(textField_27.getText());
                
                for(i=0; i<3; i++){
                    
                    for(j=0; j<3; j++){
                    
                        matriz_c[i][j] = matriz_a[i][j] + matriz_b[i][j];
                    }
                
                
                }    
                
                
                
                textField_1 = new JTextField();
        		textField_1.setEditable(false);
        		textField_1.setColumns(10);
        		textField_1.setBounds(268, 456, 34, 35);
	      		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_1.setForeground(SystemColor.black);
        		panel.add(textField_1);
        		textField_1.setText(String.valueOf(matriz_c[0][0]));
        		

        		textField_11 = new JTextField();
        		textField_11.setEditable(false);
        		textField_11.setColumns(10);
        		textField_11.setBounds(312, 456, 34, 35);
        		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_11.setForeground(SystemColor.black);
        		panel.add(textField_11);
        		textField_11.setText(String.valueOf(matriz_c[0][1]));
        		
        		textField_12 = new JTextField();
        		textField_12.setEditable(false);
        		textField_12.setColumns(10);
        		textField_12.setBounds(356, 456, 34, 35);
        		textField_12.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_12.setForeground(SystemColor.black);
        		panel.add(textField_12);
        		textField_12.setText(String.valueOf(matriz_c[0][2]));
        		
        		textField_13 = new JTextField();
        		textField_13.setEditable(false);
        		textField_13.setColumns(10);
        		textField_13.setBounds(268, 500, 34, 35);
        		textField_13.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_13.setForeground(SystemColor.black);
        		panel.add(textField_13);
        		textField_13.setText(String.valueOf(matriz_c[1][0]));
        		
        		textField_14 = new JTextField();
        		textField_14.setEditable(false);
        		textField_14.setColumns(10);
        		textField_14.setBounds(312, 500, 34, 35);
        		textField_14.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_14.setForeground(SystemColor.black);
        		panel.add(textField_14);
        		textField_14.setText(String.valueOf(matriz_c[1][1]));
        		
        		textField_15 = new JTextField();
        		textField_15.setEditable(false);
        		textField_15.setColumns(10);
        		textField_15.setBounds(356, 500, 34, 35);
        		textField_15.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_15.setForeground(SystemColor.black);
        		panel.add(textField_15);
        		textField_15.setText(String.valueOf(matriz_c[1][2]));
        		
        		textField_16 = new JTextField();
        		textField_16.setEditable(false);
        		textField_16.setColumns(10);
        		textField_16.setBounds(268, 546, 34, 35);
        		textField_16.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_16.setForeground(SystemColor.black);
        		panel.add(textField_16);      		textField_16.setText(String.valueOf(matriz_c[2][0]));
        		
        		textField_17 = new JTextField();
        		textField_17.setEditable(false);
        		textField_17.setColumns(10);
        		textField_17.setBounds(312, 546, 34, 35);
        		textField_17.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_17.setForeground(SystemColor.black);
        		panel.add(textField_17);
        		textField_17.setText(String.valueOf(matriz_c[2][1]));
        		
        		textField_18 = new JTextField();
        		textField_18.setEditable(false);
        		textField_18.setColumns(10);
        		textField_18.setBounds(356, 546, 34, 35);
        		textField_18.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_18.setForeground(SystemColor.black);
        		panel.add(textField_18);
        		textField_18.setText(String.valueOf(matriz_c[2][2]));
               
                
			}
		});
		btnSum_3_1.setBorder(null);
		btnSum_3_1.setBackground(Color.WHITE);
		btnSum_3_1.setBounds(25, 384, 70, 39);
		panel.add(btnSum_3_1);
		
		JLabel lblIngresarCantidadDe_1 = new JLabel("Ingresar valores cada matriz");
		lblIngresarCantidadDe_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblIngresarCantidadDe_1.setBounds(180, 105, 233, 46);
		panel.add(lblIngresarCantidadDe_1);
		
		JLabel lblFila = new JLabel("Fila 1");
		lblFila.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila.setBounds(10, 154, 117, 46);
		panel.add(lblFila);
		
		JLabel lblFila_1 = new JLabel("Fila 2");
		lblFila_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila_1.setBounds(10, 200, 117, 46);
		panel.add(lblFila_1);
		
		JLabel lblFila_2 = new JLabel("Fila 3");
		lblFila_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila_2.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila_2.setBounds(10, 246, 117, 46);
		panel.add(lblFila_2);
		
		txtGf = new JTextField();
		txtGf.setFont(new Font("Arial", Font.PLAIN, 15));
		txtGf.setText("\r\n");
		txtGf.setColumns(10);
		txtGf.setBounds(130, 162, 34, 35);
		panel.add(txtGf);
		
		textField_5 = new JTextField();
		textField_5.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_5.setColumns(10);
		textField_5.setBounds(130, 208, 34, 35);
		panel.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_6.setColumns(10);
		textField_6.setBounds(175, 208, 34, 35);
		panel.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_7.setColumns(10);
		textField_7.setBounds(219, 208, 34, 35);
		panel.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_8.setColumns(10);
		textField_8.setBounds(130, 254, 34, 35);
		panel.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_9.setColumns(10);
		textField_9.setBounds(175, 254, 34, 35);
		panel.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_10.setColumns(10);
		textField_10.setBounds(219, 254, 34, 35);
		panel.add(textField_10);
		
		JButton btnSum_3_1_1 = new JButton("RESTA");
		btnSum_3_1_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3_1_1.setBorder(null);
		btnSum_3_1_1.setBackground(Color.WHITE);
		btnSum_3_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
                int i, j;
                
                int[][] matriz_a = new int[3][3];
                int[][] matriz_b = new int[3][3];
                int[][] matriz_c = new int[3][3];
                
                
                matriz_a[0][0] = Integer.parseInt(txtGf.getText());
                matriz_a[0][1] = Integer.parseInt(textField_3.getText());
                matriz_a[0][2] = Integer.parseInt(textField_4.getText());
                matriz_a[1][0] = Integer.parseInt(textField_5.getText());
                matriz_a[1][1] = Integer.parseInt(textField_6.getText());
                matriz_a[1][2] = Integer.parseInt(textField_7.getText());
                matriz_a[2][0] = Integer.parseInt(textField_8.getText());
                matriz_a[2][1] = Integer.parseInt(textField_9.getText());
                matriz_a[2][2] = Integer.parseInt(textField_10.getText());
                
                matriz_b[0][0] = Integer.parseInt(textField_19.getText());
                matriz_b[0][1] = Integer.parseInt(textField_20.getText());
                matriz_b[0][2] = Integer.parseInt(textField_21.getText());
                matriz_b[1][0] = Integer.parseInt(textField_22.getText());
                matriz_b[1][1] = Integer.parseInt(textField_23.getText());
                matriz_b[1][2] = Integer.parseInt(textField_24.getText());
                matriz_b[2][0] = Integer.parseInt(textField_25.getText());
                matriz_b[2][1] = Integer.parseInt(textField_26.getText());
                matriz_b[2][2] = Integer.parseInt(textField_27.getText());
                
                for(i=0; i<3; i++){
                    
                    for(j=0; j<3; j++){
                    
                        matriz_c[i][j] = matriz_a[i][j] - matriz_b[i][j];
                    }
                
                
                }    
                
                
                
                textField_1 = new JTextField();
        		textField_1.setEditable(false);
        		textField_1.setColumns(10);
        		textField_1.setBounds(268, 456, 34, 35);
	      		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_1.setForeground(SystemColor.black);
        		panel.add(textField_1);
        		textField_1.setText(String.valueOf(matriz_c[0][0]));
        		

        		textField_11 = new JTextField();
        		textField_11.setEditable(false);
        		textField_11.setColumns(10);
        		textField_11.setBounds(312, 456, 34, 35);
        		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_11.setForeground(SystemColor.black);
        		panel.add(textField_11);
        		textField_11.setText(String.valueOf(matriz_c[0][1]));
        		
        		textField_12 = new JTextField();
        		textField_12.setEditable(false);
        		textField_12.setColumns(10);
        		textField_12.setBounds(356, 456, 34, 35);
        		textField_12.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_12.setForeground(SystemColor.black);
        		panel.add(textField_12);
        		textField_12.setText(String.valueOf(matriz_c[0][2]));
        		
        		textField_13 = new JTextField();
        		textField_13.setEditable(false);
        		textField_13.setColumns(10);
        		textField_13.setBounds(268, 500, 34, 35);
        		textField_13.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_13.setForeground(SystemColor.black);
        		panel.add(textField_13);
        		textField_13.setText(String.valueOf(matriz_c[1][0]));
        		
        		textField_14 = new JTextField();
        		textField_14.setEditable(false);
        		textField_14.setColumns(10);
        		textField_14.setBounds(312, 500, 34, 35);
        		textField_14.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_14.setForeground(SystemColor.black);
        		panel.add(textField_14);
        		textField_14.setText(String.valueOf(matriz_c[1][1]));
        		
        		textField_15 = new JTextField();
        		textField_15.setEditable(false);
        		textField_15.setColumns(10);
        		textField_15.setBounds(356, 500, 34, 35);
        		textField_15.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_15.setForeground(SystemColor.black);
        		panel.add(textField_15);
        		textField_15.setText(String.valueOf(matriz_c[1][2]));
        		
        		textField_16 = new JTextField();
        		textField_16.setEditable(false);
        		textField_16.setColumns(10);
        		textField_16.setBounds(268, 546, 34, 35);
        		textField_16.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_16.setForeground(SystemColor.black);
        		panel.add(textField_16);      		textField_16.setText(String.valueOf(matriz_c[2][0]));
        		
        		textField_17 = new JTextField();
        		textField_17.setEditable(false);
        		textField_17.setColumns(10);
        		textField_17.setBounds(312, 546, 34, 35);
        		textField_17.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_17.setForeground(SystemColor.black);
        		panel.add(textField_17);
        		textField_17.setText(String.valueOf(matriz_c[2][1]));
        		
        		textField_18 = new JTextField();
        		textField_18.setEditable(false);
        		textField_18.setColumns(10);
        		textField_18.setBounds(356, 546, 34, 35);
        		textField_18.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_18.setForeground(SystemColor.black);
        		panel.add(textField_18);
        		textField_18.setText(String.valueOf(matriz_c[2][2]));
               
                
			}
		});
		btnSum_3_1_1.setBounds(101, 384, 88, 39);
		panel.add(btnSum_3_1_1);
		
		JButton btnSum_3_1_2 = new JButton("MULTIPLICACION");
		btnSum_3_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
                int i, j, k;
                
                int[][] matriz_a = new int[3][3];
                int[][] matriz_b = new int[3][3];
                int[][] matriz_c = new int[3][3];
                
                
                matriz_a[0][0] = Integer.parseInt(txtGf.getText());
                matriz_a[0][1] = Integer.parseInt(textField_3.getText());
                matriz_a[0][2] = Integer.parseInt(textField_4.getText());
                matriz_a[1][0] = Integer.parseInt(textField_5.getText());
                matriz_a[1][1] = Integer.parseInt(textField_6.getText());
                matriz_a[1][2] = Integer.parseInt(textField_7.getText());
                matriz_a[2][0] = Integer.parseInt(textField_8.getText());
                matriz_a[2][1] = Integer.parseInt(textField_9.getText());
                matriz_a[2][2] = Integer.parseInt(textField_10.getText());
                
                matriz_b[0][0] = Integer.parseInt(textField_19.getText());
                matriz_b[0][1] = Integer.parseInt(textField_20.getText());
                matriz_b[0][2] = Integer.parseInt(textField_21.getText());
                matriz_b[1][0] = Integer.parseInt(textField_22.getText());
                matriz_b[1][1] = Integer.parseInt(textField_23.getText());
                matriz_b[1][2] = Integer.parseInt(textField_24.getText());
                matriz_b[2][0] = Integer.parseInt(textField_25.getText());
                matriz_b[2][1] = Integer.parseInt(textField_26.getText());
                matriz_b[2][2] = Integer.parseInt(textField_27.getText());
                
                for (i = 0; i < 3; i++) {
                    for (j = 0; j < 3; j++) {
                        matriz_c[i][j] = 0;
                    for (k = 0; k < 3; k++) {
                            matriz_c[i][j] += matriz_a[i][k] * matriz_b[k][j];
                    }
                    }
                }
                
                
                
                textField_1 = new JTextField();
        		textField_1.setEditable(false);
        		textField_1.setColumns(10);
        		textField_1.setBounds(268, 456, 34, 35);
	      		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_1.setForeground(SystemColor.black);
        		panel.add(textField_1);
        		textField_1.setText(String.valueOf(matriz_c[0][0]));
        		

        		textField_11 = new JTextField();
        		textField_11.setEditable(false);
        		textField_11.setColumns(10);
        		textField_11.setBounds(312, 456, 34, 35);
        		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_11.setForeground(SystemColor.black);
        		panel.add(textField_11);
        		textField_11.setText(String.valueOf(matriz_c[0][1]));
        		
        		textField_12 = new JTextField();
        		textField_12.setEditable(false);
        		textField_12.setColumns(10);
        		textField_12.setBounds(356, 456, 34, 35);
        		textField_12.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_12.setForeground(SystemColor.black);
        		panel.add(textField_12);
        		textField_12.setText(String.valueOf(matriz_c[0][2]));
        		
        		textField_13 = new JTextField();
        		textField_13.setEditable(false);
        		textField_13.setColumns(10);
        		textField_13.setBounds(268, 500, 34, 35);
        		textField_13.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_13.setForeground(SystemColor.black);
        		panel.add(textField_13);
        		textField_13.setText(String.valueOf(matriz_c[1][0]));
        		
        		textField_14 = new JTextField();
        		textField_14.setEditable(false);
        		textField_14.setColumns(10);
        		textField_14.setBounds(312, 500, 34, 35);
        		textField_14.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_14.setForeground(SystemColor.black);
        		panel.add(textField_14);
        		textField_14.setText(String.valueOf(matriz_c[1][1]));
        		
        		textField_15 = new JTextField();
        		textField_15.setEditable(false);
        		textField_15.setColumns(10);
        		textField_15.setBounds(356, 500, 34, 35);
        		textField_15.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_15.setForeground(SystemColor.black);
        		panel.add(textField_15);
        		textField_15.setText(String.valueOf(matriz_c[1][2]));
        		
        		textField_16 = new JTextField();
        		textField_16.setEditable(false);
        		textField_16.setColumns(10);
        		textField_16.setBounds(268, 546, 34, 35);
        		textField_16.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_16.setForeground(SystemColor.black);
        		panel.add(textField_16);      		textField_16.setText(String.valueOf(matriz_c[2][0]));
        		
        		textField_17 = new JTextField();
        		textField_17.setEditable(false);
        		textField_17.setColumns(10);
        		textField_17.setBounds(312, 546, 34, 35);
        		textField_17.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_17.setForeground(SystemColor.black);
        		panel.add(textField_17);
        		textField_17.setText(String.valueOf(matriz_c[2][1]));
        		
        		textField_18 = new JTextField();
        		textField_18.setEditable(false);
        		textField_18.setColumns(10);
        		textField_18.setBounds(356, 546, 34, 35);
        		textField_18.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_18.setForeground(SystemColor.black);
        		panel.add(textField_18);
        		textField_18.setText(String.valueOf(matriz_c[2][2]));
               
                
			}
		});
		btnSum_3_1_2.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3_1_2.setBorder(null);
		btnSum_3_1_2.setBackground(Color.WHITE);
		btnSum_3_1_2.setBounds(203, 384, 132, 39);
		panel.add(btnSum_3_1_2);
		
		JButton btnSum_3_1_3 = new JButton("DIVISION");
		btnSum_3_1_3.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3_1_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
                
                float[][] matriz_a = new float[3][3];
                float[][] matriz_b = new float[3][3];
                float[][] matriz_c = new float[3][3];
                float[][] matriz_akd = new float[3][3];
                
                
                matriz_a[0][0] = Integer.parseInt(txtGf.getText());
                matriz_a[0][1] = Integer.parseInt(textField_3.getText());
                matriz_a[0][2] = Integer.parseInt(textField_4.getText());
                matriz_a[1][0] = Integer.parseInt(textField_5.getText());
                matriz_a[1][1] = Integer.parseInt(textField_6.getText());
                matriz_a[1][2] = Integer.parseInt(textField_7.getText());
                matriz_a[2][0] = Integer.parseInt(textField_8.getText());
                matriz_a[2][1] = Integer.parseInt(textField_9.getText());
                matriz_a[2][2] = Integer.parseInt(textField_10.getText());
                
                matriz_b[0][0] = Integer.parseInt(textField_19.getText());
                matriz_b[0][1] = Integer.parseInt(textField_20.getText());
                matriz_b[0][2] = Integer.parseInt(textField_21.getText());
                matriz_b[1][0] = Integer.parseInt(textField_22.getText());
                matriz_b[1][1] = Integer.parseInt(textField_23.getText());
                matriz_b[1][2] = Integer.parseInt(textField_24.getText());
                matriz_b[2][0] = Integer.parseInt(textField_25.getText());
                matriz_b[2][1] = Integer.parseInt(textField_26.getText());
                matriz_b[2][2] = Integer.parseInt(textField_27.getText());
                
                int n = 3;
                
                float[][] I =  {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};

                for(int i=0; i<3; i++){
                    
                    for(int j=0;j<3;j++){
                        
                        matriz_akd[i][j] = matriz_a[i][j];
                        
                    }
                    
                }
                for (int k = 0; k < n; k++) {
                    double pivot = matriz_b[k][k];
                    for (int j = 0; j < n; j++) {
                        matriz_b[k][j] /= pivot;
                        I[k][j] /= pivot;
                    }
                    for (int i = k+1; i < n; i++) {
                        double factor = matriz_b[i][k];
                        for (int j = 0; j < n; j++) {
                        matriz_b[i][j] -= factor * matriz_b[k][j];
                        I[i][j] -= factor * I[k][j];
                        }
                    }
                    }
                    for (int k = n-1; k >= 0; k--) {
                    for (int i = k-1; i >= 0; i--) {
                        double factor = matriz_b[i][k];
                        for (int j = 0; j < n; j++) {
                        matriz_b[i][j] -= factor * matriz_b[k][j];
                        I[i][j] -= factor * I[k][j];
                        }
                    }
                    }
                    
                    for(int i=0; i<3; i++){
            
                        for(int j=0; j<n; j++){
                        
                            matriz_c[i][j] = matriz_akd[i][j] * I[i][j];
                        
                        }
                    
                    
                    }
                
                
                textField_1 = new JTextField();
        		textField_1.setEditable(false);
        		textField_1.setColumns(10);
        		textField_1.setBounds(268, 456, 34, 35);
	      		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_1.setForeground(SystemColor.black);
        		panel.add(textField_1);
        		textField_1.setText(String.valueOf(matriz_c[0][0]));
        		

        		textField_11 = new JTextField();
        		textField_11.setEditable(false);
        		textField_11.setColumns(10);
        		textField_11.setBounds(312, 456, 34, 35);
        		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_11.setForeground(SystemColor.black);
        		panel.add(textField_11);
        		textField_11.setText(String.valueOf(matriz_c[0][1]));
        		
        		textField_12 = new JTextField();
        		textField_12.setEditable(false);
        		textField_12.setColumns(10);
        		textField_12.setBounds(356, 456, 34, 35);
        		textField_12.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_12.setForeground(SystemColor.black);
        		panel.add(textField_12);
        		textField_12.setText(String.valueOf(matriz_c[0][2]));
        		
        		textField_13 = new JTextField();
        		textField_13.setEditable(false);
        		textField_13.setColumns(10);
        		textField_13.setBounds(268, 500, 34, 35);
        		textField_13.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_13.setForeground(SystemColor.black);
        		panel.add(textField_13);
        		textField_13.setText(String.valueOf(matriz_c[1][0]));
        		
        		textField_14 = new JTextField();
        		textField_14.setEditable(false);
        		textField_14.setColumns(10);
        		textField_14.setBounds(312, 500, 34, 35);
        		textField_14.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_14.setForeground(SystemColor.black);
        		panel.add(textField_14);
        		textField_14.setText(String.valueOf(matriz_c[1][1]));
        		
        		textField_15 = new JTextField();
        		textField_15.setEditable(false);
        		textField_15.setColumns(10);
        		textField_15.setBounds(356, 500, 34, 35);
        		textField_15.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_15.setForeground(SystemColor.black);
        		panel.add(textField_15);
        		textField_15.setText(String.valueOf(matriz_c[1][2]));
        		
        		textField_16 = new JTextField();
        		textField_16.setEditable(false);
        		textField_16.setColumns(10);
        		textField_16.setBounds(268, 546, 34, 35);
        		textField_16.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_16.setForeground(SystemColor.black);
        		panel.add(textField_16);      		textField_16.setText(String.valueOf(matriz_c[2][0]));
        		
        		textField_17 = new JTextField();
        		textField_17.setEditable(false);
        		textField_17.setColumns(10);
        		textField_17.setBounds(312, 546, 34, 35);
        		textField_17.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_17.setForeground(SystemColor.black);
        		panel.add(textField_17);
        		textField_17.setText(String.valueOf(matriz_c[2][1]));
        		
        		textField_18 = new JTextField();
        		textField_18.setEditable(false);
        		textField_18.setColumns(10);
        		textField_18.setBounds(356, 546, 34, 35);
        		textField_18.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_18.setForeground(SystemColor.black);
        		panel.add(textField_18);
        		textField_18.setText(String.valueOf(matriz_c[2][2]));
               
                
			}
		});
		btnSum_3_1_3.setBorder(null);
		btnSum_3_1_3.setBackground(Color.WHITE);
		btnSum_3_1_3.setBounds(345, 384, 103, 39);
		panel.add(btnSum_3_1_3);
		
		textField_19 = new JTextField();
		textField_19.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_19.setColumns(10);
		textField_19.setBounds(353, 162, 34, 35);
		panel.add(textField_19);
		
		textField_20 = new JTextField();
		textField_20.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_20.setColumns(10);
		textField_20.setBounds(397, 162, 34, 35);
		panel.add(textField_20);
		
		textField_21 = new JTextField();
		textField_21.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_21.setColumns(10);
		textField_21.setBounds(441, 162, 34, 35);
		panel.add(textField_21);
		
		textField_22 = new JTextField();
		textField_22.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_22.setColumns(10);
		textField_22.setBounds(353, 208, 34, 35);
		panel.add(textField_22);
		
		textField_23 = new JTextField();
		textField_23.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_23.setColumns(10);
		textField_23.setBounds(397, 208, 34, 35);
		panel.add(textField_23);
		
		textField_24 = new JTextField();
		textField_24.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_24.setColumns(10);
		textField_24.setBounds(441, 208, 34, 35);
		panel.add(textField_24);
		
		textField_25 = new JTextField();
		textField_25.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_25.setColumns(10);
		textField_25.setBounds(353, 254, 34, 35);
		panel.add(textField_25);
		
		textField_26 = new JTextField();
		textField_26.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_26.setColumns(10);
		textField_26.setBounds(397, 254, 34, 35);
		panel.add(textField_26);
		
		textField_27 = new JTextField();
		textField_27.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_27.setColumns(10);
		textField_27.setBounds(441, 254, 34, 35);
		panel.add(textField_27);
		
		textField_2 = new JTextField();
		textField_2.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_2.setColumns(10);
		textField_2.setBounds(174, 162, 34, 35);
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setFont(new Font("Arial", Font.PLAIN, 15));
		textField_3.setColumns(10);
		textField_3.setBounds(219, 162, 34, 35);
		panel.add(textField_3);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}