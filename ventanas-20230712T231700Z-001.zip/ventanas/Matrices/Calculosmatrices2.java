package ventanas;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import java.awt.SystemColor;


public class Calculosmatrices2 extends JFrame implements ActionListener{
	private JButton btnSum_1;
	private JButton btnSum_2;
	private JButton btnSum_3;
	private JButton btnSum_4;
	private JPanel contentPane;
	private JPanel panel;
	private JTextField textField;
	private JLabel lblMostrar;
	private JButton btnNewButton_6;
	private JPanel resultadoPane;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JTextField textField_6;
	private JTextField textField_7;
	private JTextField textField_8;
	private JTextField textField_9;
	private JTextField textField_10;
	private JTextField textField_1;
	private JTextField textField_11;
	private JTextField textField_12;
	private JTextField textField_13;
	private JTextField textField_14;
	private JTextField textField_15;
	private JTextField textField_16;
	private JTextField textField_17;
	private JTextField textField_18;
	private JTextField textField22;
	private JTextField textField_40;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculosmatrices2 frame = new Calculosmatrices2();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Calculosmatrices2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 758);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 596, 697);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("MATRICES");
		lblNewLabel_1.setBounds(101, 11, 378, 39);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 33));
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("OPERACIONES CON 1 MATRIZ");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1_1.setBounds(130, 55, 308, 39);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblMostrar = new JLabel("El resultado es: ");
		lblMostrar.setHorizontalAlignment(SwingConstants.CENTER);
		lblMostrar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblMostrar.setBounds(94, 517, 171, 46);
		panel.add(lblMostrar);
		
		JLabel lblNum4 = new JLabel("¿Que operacion desea realizar?");
		lblNum4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNum4.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNum4.setBounds(101, 376, 403, 46);
		panel.add(lblNum4);
		
		btnNewButton_6 = new JButton("VOLVER");
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Matrices frame = new Matrices();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setBackground(Color.WHITE);
		btnNewButton_6.setBounds(355, 451, 124, 39);
		panel.add(btnNewButton_6);
		
		JButton btnSum_3_1 = new JButton("MULTIPLICACION POR ESCALAR\r\n");
		btnSum_3_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnSum_3_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int num = Integer.parseInt(textField_40.getText());
                int i, j;
                
                int[][] matriz = new int[3][3];
                int[][] matriz_b = new int[3][3];
                
                
                matriz[0][0] = Integer.parseInt(textField_2.getText());
                matriz[0][1] = Integer.parseInt(textField_3.getText());
                matriz[0][2] = Integer.parseInt(textField_4.getText());
                matriz[1][0] = Integer.parseInt(textField_5.getText());
                matriz[1][1] = Integer.parseInt(textField_6.getText());
                matriz[1][2] = Integer.parseInt(textField_7.getText());
                matriz[2][0] = Integer.parseInt(textField_8.getText());
                matriz[2][1] = Integer.parseInt(textField_9.getText());
                matriz[2][2] = Integer.parseInt(textField_10.getText());
                
                for(i=0; i<3; i++){
                    
                    for(j=0; j<3; j++){
                    
                        matriz_b[i][j] = matriz[i][j] * num;
                    
                    }
                
                
                } 
                
                
                textField_1 = new JTextField();
        		textField_1.setEditable(false);
        		textField_1.setColumns(10);
        		textField_1.setBounds(268, 526, 34, 35);
	      		textField_1.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_1.setForeground(SystemColor.black);
        		panel.add(textField_1);
        		textField_1.setText(String.valueOf(matriz_b[0][0]));
        		

        		textField_11 = new JTextField();
        		textField_11.setEditable(false);
        		textField_11.setColumns(10);
        		textField_11.setBounds(312, 526, 34, 35);
        		textField_11.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_11.setForeground(SystemColor.black);
        		panel.add(textField_11);
        		textField_11.setText(String.valueOf(matriz_b[0][1]));
        		
        		textField_12 = new JTextField();
        		textField_12.setEditable(false);
        		textField_12.setColumns(10);
        		textField_12.setBounds(356, 526, 34, 35);
        		textField_12.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_12.setForeground(SystemColor.black);
        		panel.add(textField_12);
        		textField_12.setText(String.valueOf(matriz_b[0][2]));
        		
        		textField_13 = new JTextField();
        		textField_13.setEditable(false);
        		textField_13.setColumns(10);
        		textField_13.setBounds(268, 570, 34, 35);
        		textField_13.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_13.setForeground(SystemColor.black);
        		panel.add(textField_13);
        		textField_13.setText(String.valueOf(matriz_b[1][0]));
        		
        		textField_14 = new JTextField();
        		textField_14.setEditable(false);
        		textField_14.setColumns(10);
        		textField_14.setBounds(312, 570, 34, 35);
        		textField_14.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_14.setForeground(SystemColor.black);
        		panel.add(textField_14);
        		textField_14.setText(String.valueOf(matriz_b[1][1]));
        		
        		textField_15 = new JTextField();
        		textField_15.setEditable(false);
        		textField_15.setColumns(10);
        		textField_15.setBounds(356, 570, 34, 35);
        		textField_15.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_15.setForeground(SystemColor.black);
        		panel.add(textField_15);
        		textField_15.setText(String.valueOf(matriz_b[1][2]));
        		
        		textField_16 = new JTextField();
        		textField_16.setEditable(false);
        		textField_16.setColumns(10);
        		textField_16.setBounds(268, 616, 34, 35);
        		textField_16.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_16.setForeground(SystemColor.black);
        		panel.add(textField_16);
        		textField_16.setText(String.valueOf(matriz_b[2][0]));
        		
        		textField_17 = new JTextField();
        		textField_17.setEditable(false);
        		textField_17.setColumns(10);
        		textField_17.setBounds(312, 616, 34, 35);
        		textField_17.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_17.setForeground(SystemColor.black);
        		panel.add(textField_17);
        		textField_17.setText(String.valueOf(matriz_b[2][1]));
        		
        		textField_18 = new JTextField();
        		textField_18.setEditable(false);
        		textField_18.setColumns(10);
        		textField_18.setBounds(356, 616, 34, 35);
        		textField_18.setFont(new Font("Arial", Font.PLAIN, 17));
	      		textField_18.setForeground(SystemColor.black);
        		panel.add(textField_18);
        		textField_18.setText(String.valueOf(matriz_b[2][2]));
               
                
			}
		});
		btnSum_3_1.setBorder(null);
		btnSum_3_1.setBackground(Color.WHITE);
		btnSum_3_1.setBounds(94, 451, 233, 39);
		panel.add(btnSum_3_1);
		
		JLabel lblIngresarCantidadDe_1 = new JLabel("Ingresar valores para la matriz");
		lblIngresarCantidadDe_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblIngresarCantidadDe_1.setBounds(180, 105, 233, 46);
		panel.add(lblIngresarCantidadDe_1);
		
		JLabel lblFila = new JLabel("Fila 1");
		lblFila.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila.setBounds(93, 154, 155, 46);
		panel.add(lblFila);
		
		JLabel lblFila_1 = new JLabel("Fila 2");
		lblFila_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila_1.setBounds(93, 200, 155, 46);
		panel.add(lblFila_1);
		
		JLabel lblFila_2 = new JLabel("Fila 3");
		lblFila_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblFila_2.setFont(new Font("Arial", Font.PLAIN, 17));
		lblFila_2.setBounds(93, 246, 155, 46);
		panel.add(lblFila_2);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(249, 162, 34, 35);
		textField_2.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_2.setForeground(SystemColor.black);
		panel.add(textField_2);
		
		textField_3 = new JTextField();
		textField_3.setColumns(10);
		textField_3.setBounds(293, 162, 34, 35);
		textField_3.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_3.setForeground(SystemColor.black);
		panel.add(textField_3);
		
		textField_4 = new JTextField();
		textField_4.setColumns(10);
		textField_4.setBounds(337, 162, 34, 35);
		textField_4.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_4.setForeground(SystemColor.black);
		panel.add(textField_4);
		
		textField_5 = new JTextField();
		textField_5.setColumns(10);
		textField_5.setBounds(249, 208, 34, 35);
		textField_5.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_5.setForeground(SystemColor.black);
		panel.add(textField_5);
		
		textField_6 = new JTextField();
		textField_6.setColumns(10);
		textField_6.setBounds(293, 208, 34, 35);
		textField_6.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_6.setForeground(SystemColor.black);
		panel.add(textField_6);
		
		textField_7 = new JTextField();
		textField_7.setColumns(10);
		textField_7.setBounds(336, 208, 34, 35);
		textField_7.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_7.setForeground(SystemColor.black);
		panel.add(textField_7);
		
		textField_8 = new JTextField();
		textField_8.setColumns(10);
		textField_8.setBounds(249, 254, 34, 35);
		textField_8.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_8.setForeground(SystemColor.black);
		panel.add(textField_8);
		
		textField_9 = new JTextField();
		textField_9.setColumns(10);
		textField_9.setBounds(293, 254, 34, 35);
		textField_9.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_9.setForeground(SystemColor.black);
		panel.add(textField_9);
		
		textField_10 = new JTextField();
		textField_10.setColumns(10);
		textField_10.setBounds(337, 254, 34, 35);
		textField_10.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_10.setForeground(SystemColor.black);
		panel.add(textField_10);
		
		JLabel lblIngresarEscalar = new JLabel("Ingrese escalar\r");
		lblIngresarEscalar.setHorizontalAlignment(SwingConstants.CENTER);
		lblIngresarEscalar.setFont(new Font("Arial", Font.PLAIN, 17));
		lblIngresarEscalar.setBounds(132, 319, 171, 46);
		panel.add(lblIngresarEscalar);
		
		textField_40 = new JTextField();
		textField_40.setColumns(10);
		textField_40.setBounds(293, 327, 34, 35);
		textField_40.setFont(new Font("Arial", Font.PLAIN, 17));
  		textField_40.setForeground(SystemColor.black);
		panel.add(textField_40);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
}