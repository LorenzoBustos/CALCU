package ventanas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Matrices extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Matrices frame = new Matrices();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Matrices() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 357);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 414, 296);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("MATRICES");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel.setBounds(68, 5, 264, 44);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("¿QUE OPERACION DESEA REALIZAR?");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(54, 60, 313, 35);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("OPERACIONES ENTRE 2 MATRICES");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Calculosmatrices frame = new Calculosmatrices();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setBounds(54, 106, 313, 35);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("ESCALAR POR MATRIZ");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {	
				Calculosmatrices2 frame = new Calculosmatrices2();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(54, 152, 313, 35);
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setBackground(Color.WHITE);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("OPERACIONES CON UNA MATRIZ");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Calculosmatrices3 frame = new Calculosmatrices3();
				frame.setVisible(true);
				dispose();				
			}
		});
		btnNewButton_3.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_3.setBorder(null);
		btnNewButton_3.setBackground(Color.WHITE);
		btnNewButton_3.setBounds(54, 198, 313, 35);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_3_1 = new JButton("VOLVER");
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Inicio frame = new Inicio();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_3_1.setBounds(54, 244, 313, 35);
		btnNewButton_3_1.setBorder(null);
		btnNewButton_3_1.setBackground(Color.WHITE);
		panel.add(btnNewButton_3_1);
	}
}