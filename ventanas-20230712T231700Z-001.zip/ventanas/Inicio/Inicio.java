package ventanas;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.MatteBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.UIManager;
import javax.swing.border.EtchedBorder;
import java.awt.SystemColor;

public class Inicio extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Inicio frame = new Inicio();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Inicio() {
		setTitle("CALCULADORA");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 632, 760);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 0, 0));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(104, 141, 204));
		panel.setBounds(10, 11, 592, 699);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CALCULADORA");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 33));
		lblNewLabel.setSize(new Dimension(4, 4));
		
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(10, 11, 572, 45);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("\u00BFCON QUE ELEMENTOS DESEA TRABAJAR?");
		lblNewLabel_1.setFont(new Font("Arial", Font.PLAIN, 17));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(20, 67, 572, 39);
		panel.add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("NUMEROS NATURALES");
		btnNewButton.setBorder(null);
		btnNewButton.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ventana frame = new Ventana();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(10, 113, 572, 106);
		panel.add(btnNewButton);
		
		JButton btnNewButton_2 = new JButton("SISTEMA DE ECUACIONES");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.setForeground(new Color(0, 0, 0));
		btnNewButton_2.setBorder(null);
		btnNewButton_2.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Ecuaciones frame = new Ecuaciones();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(10, 347, 572, 106);
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("MATRICES");
		btnNewButton_3.setBackground(new Color(255, 255, 255));
		btnNewButton_3.setForeground(new Color(0, 0, 0));
		btnNewButton_3.setBorder(null);
		btnNewButton_3.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Matrices frame = new Matrices();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_3.setBounds(10, 465, 572, 106);
		panel.add(btnNewButton_3);
		
		JButton btnNewButton_6 = new JButton("SALIR");
		btnNewButton_6.setBackground(new Color(255, 255, 255));
		btnNewButton_6.setForeground(new Color(0, 0, 0));
		btnNewButton_6.setBorder(null);
		btnNewButton_6.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
			}
		});
		btnNewButton_6.setBounds(10, 582, 572, 106);
		panel.add(btnNewButton_6);
		
		JButton btnNewButton_1 = new JButton("VECTORES");
		btnNewButton_1.setForeground(new Color(0, 0, 0));
		btnNewButton_1.setBorder(null);
		btnNewButton_1.setFont(new Font("Arial", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Vectores frame = new Vectores();
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(10, 230, 572, 106);
		panel.add(btnNewButton_1);
	}

}